return require 'goldsmith.telescope'.register()
