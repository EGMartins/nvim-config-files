goimport not stable (failed on 2nd time from time to time)
gomodifytags
goimport: could not import.... auto import by run 'go get' "not in your go.mod" append to gomod
key mappings/nvim commands
GoTests -- add unit test
