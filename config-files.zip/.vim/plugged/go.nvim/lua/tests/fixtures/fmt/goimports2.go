package main

func foo() {
	fmt.Println("vim-go")
}
