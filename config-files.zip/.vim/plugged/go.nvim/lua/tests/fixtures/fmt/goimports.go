package main

func main() {
	fmt.Println("vim-go")
}
