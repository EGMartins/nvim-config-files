package main

import "fmt"

func foo() {
	fmt.Println("vim-go")
}
